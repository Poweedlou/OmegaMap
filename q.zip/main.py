import sys
from io import BytesIO
from scale import scale
# Этот класс поможет нам сделать картинку из потока байт

import requests
import pygame

# Пусть наше приложение предполагает запуск:
# python search.py Москва, ул. Ак. Королева, 12
# Тогда запрос к геокодеру формируется следующим образом:
toponym_to_find = " ".join(sys.argv[1:])
coords, spn = scale(toponym_to_find)


map_params = {
    "ll": ','.join(map(str, coords)),
    "spn": f'{spn},{spn}',
    "l": "map",
    "size": '600,450',
    "pt": ','.join(map(str, coords)) + ',pm2rdm'
}

map_api_server = "http://static-maps.yandex.ru/1.x/"
# ... и выполняем запрос
response = requests.get(map_api_server, params=map_params)
if not response:
    print("Ошибка")
    print("Http статус:", response.status_code, "(", response.reason, ")")
    with open('log.xml', 'wb') as err:
        err.write(response.content)
    sys.exit()
data = BytesIO(response.content)
screen = pygame.display.set_mode((600, 450))
img = pygame.image.load(data)
screen.blit(img, (0, 0))
pygame.display.flip()
while pygame.event.wait().type != pygame.QUIT:
    pass
pygame.quit()